//
//  ViewController.m
//  HomeWork Lesson 32 (UITableView Editing Part 2)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGGroup.h"
#import "AGPlayers.h"

@interface ViewController ()

@end

/*
 Урок номер 31 - 32. UITableView Editing.
 Итак редактируем наши таблицы.
 
 Задание.
 
 Ученик (в новом XCODE нельзя создавать пустое приложение!!!)
 
 1. Создайте контроллер с таблицей в коде без сторибордов.
 2. Заполните таблицу данными на свое усмотрение
 3. Объедините данные в группы (секции)
 
 Студент.
 
 4. Реализуйте механизм перемещения данных между рядами и секциями
 5. Вы должны четко понимать что и как работает и в какой последовательности поэтому повторяйте задание пока вы полностью не освоите этот механизм
 
 Мастер.
 
 6. Реализуйте удаление рядов
 
 Супермен
 
 7. Реализуйте механзм добавления секций и рядов на ваше усмотрение
*/
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self statusBarInsets];
    
    self.view.backgroundColor = [UIColor blueColor];
    
    [self addTitle]; //название секций
    
    self.groupArray = [NSMutableArray array];
    
    for (int i = 0; i < (arc4random() % 6 + 4.f); i++) { //количество групп (секций)от 4 до 8
        
        AGGroup* group = [[AGGroup alloc ]init];
        //group.name = [NSString stringWithFormat:@"Team %d",i];
        NSMutableArray* array = [NSMutableArray array];
        
        
        for (int j = 0; j < 5; j++) {//  по 5 человек в группе
            [array addObject:[AGPlayers randomPlayers ]];
        }
        group.players = array;
        [self.groupArray addObject:group];
    }
    
   // [self.tableView reloadData]; //чтобы перезагрузить дату нашей tableView
   // self.tableView.editing = YES; //разрешить редактирование
    
    self.navigationItem.title = @"The campions cup Univer";
    
    
    UIBarButtonItem* editButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit
                                                                                target:self
                                                                                action:@selector(actionEdid:)];
    
    self.navigationItem.rightBarButtonItem = editButton;
}



#pragma mark- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return [self.groupArray count];
    
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    //return [[self.groupArray objectAtIndex:section]name];
    
    NSString* titleForHeaderInSection = [NSString stringWithFormat:@"%@",[self.teamsName objectAtIndex:section]];
    
    return titleForHeaderInSection;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    AGGroup* group = [self.groupArray objectAtIndex:section];
    
    return [group.players count] + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 0) { //если ряд по индексу = "0", то показываем выводим "AddStudent";
        
        static NSString* addStudentIdentifier = @"AddStudentCell";
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:addStudentIdentifier];
        
        if (!cell) {
            
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:addStudentIdentifier];
            cell.textLabel.textColor = [UIColor blueColor];
            cell.textLabel.text = @"Add a new student";
            
        }
        return cell;
        
    }else { //если не "0" по индексу
        
        static NSString* identifier = @"cell";
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
            cell.textLabel.textColor = [UIColor redColor];
        }
        
        AGGroup* group = [self.groupArray objectAtIndex:indexPath.section];
        AGPlayers* players = [group.players objectAtIndex:indexPath.row -1];
        
        cell.textLabel.text = [NSString stringWithFormat:@"%@",players.firstLastName];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%1.f",players.countGols];
        
        if (players.countGols >= 28) {
            
            cell.detailTextLabel.textColor = [UIColor greenColor];
            cell.textLabel.textColor = [UIColor greenColor];
        }
        
        return cell;
    }
    
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return indexPath.row > 0;
}


- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    
    AGGroup* sourceGroup = [self.groupArray objectAtIndex:sourceIndexPath.section];
    AGPlayers* players = [sourceGroup.players objectAtIndex:sourceIndexPath.row -1];
    
    NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sourceGroup.players];
    
    if (sourceIndexPath.section == destinationIndexPath.section) {
        
        [tempArray exchangeObjectAtIndex:sourceIndexPath.row -1 withObjectAtIndex:destinationIndexPath.row -1];
        sourceGroup.players = tempArray;
        
    }else {
        
        [tempArray removeObject:players];
        sourceGroup.players = tempArray;
        
        AGGroup* destinationGroup = [self.groupArray objectAtIndex:destinationIndexPath.section];
        
        tempArray = [NSMutableArray arrayWithArray:destinationGroup.players];
        [tempArray insertObject:players atIndex:destinationIndexPath.row -1];
        destinationGroup.players = tempArray;
        
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {


    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        AGGroup* sourceGroup = [self.groupArray objectAtIndex:indexPath.section];
        AGPlayers* players = [sourceGroup.players objectAtIndex:indexPath.row - 1];
        
        NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sourceGroup.players];
        [tempArray removeObject:players];
        sourceGroup.players = tempArray;
        
        
        [self.tableView beginUpdates];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        [self.tableView endUpdates];
    }

}
#pragma mark- UITableViewDelegate

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return indexPath.row == 0 ? UITableViewCellEditingStyleNone : UITableViewCellEditingStyleDelete;
    
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {

    return NO;
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath NS_AVAILABLE_IOS(3_0) __TVOS_PROHIBITED {

return @"Remove";
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath NS_AVAILABLE_IOS(3_0) {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row == 0) {
        
        AGGroup* group = [self.groupArray objectAtIndex:indexPath.section];
        NSMutableArray* tempArray = nil;
        
        if (group.players) {
            
            tempArray = [NSMutableArray arrayWithArray:group.players];
         
        }else {
        
            tempArray = [NSMutableArray array];
        }
        
        NSInteger newPlayerIndex = 0;
        
        [tempArray insertObject:[AGPlayers randomPlayers] atIndex:newPlayerIndex];
        group.players = tempArray;
        
        [self.tableView beginUpdates];
        
        NSIndexPath* newIndexPath = [NSIndexPath indexPathForItem:newPlayerIndex + 1 inSection:indexPath.section];
        [self.tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationLeft];
        
        [self.tableView endUpdates];
        
        [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            if ([[UIApplication sharedApplication] isIgnoringInteractionEvents]) {
                [[UIApplication sharedApplication] endIgnoringInteractionEvents];
            }
        });
    }
}

#pragma mark- Action

- (void) actionEdid:(UIBarButtonItem*) sender {

    BOOL isEditing = self.tableView.editing;
    
    [self.tableView setEditing:!isEditing animated:YES];
    
    UIBarButtonSystemItem item = UIBarButtonSystemItemEdit;
    
    if (self.tableView.editing) {
        
        item = UIBarButtonSystemItemDone;
    }
    
    UIBarButtonItem* editButtom = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:item
                                                                                target:self
                                                                                action:@selector(actionEdid:)];
    
    [self.navigationItem setRightBarButtonItem:editButtom animated:YES];
    

}

#pragma mark- Methods

- (void) statusBarInsets {
    
    UIEdgeInsets topInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.scrollIndicatorInsets = topInsets;
    self.tableView.contentInset = topInsets;
    
    UIEdgeInsets rightInsets = UIEdgeInsetsMake(0, 0, 0, 20);
    self.tableView.separatorInset = rightInsets;
}

- (void) addTitle {
    
    self.teamsName = [NSArray arrayWithObjects:   @"Team 1",
                                                  @"Team 2",
                                                  @"Team 3",
                                                  @"Team 4",
                                                  @"Team 5",
                                                  @"Team 6",
                                                  @"Team 7",
                                                  @"Team 8",
                                                  @"Team 9",
                                                  @"Team 10",
                                                  @"Team 11",
                                                  @"Team 12",
                                                  @"Team 13",
                                                  @"Team 14",
                                                  @"Team 15",
                                                  @"Team 16",
                                                  @"Team 17",
                                                  @"Team 18",
                                                  @"Team 19",
                                                  @"Team 20",
                                                  @"Team 21",
                                                  @"Team 22",
                                                  @"Team 23",
                                                  @"Team 24",
                                                  @"Team 25",
                                                  @"Team 26",
                                                  @"Team 27",
                                                  @"Team 28",
                                                  @"Team 29",
                                                  @"Team 30",
                                                  @"Team 31",
                                                  @"Team 32",nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
