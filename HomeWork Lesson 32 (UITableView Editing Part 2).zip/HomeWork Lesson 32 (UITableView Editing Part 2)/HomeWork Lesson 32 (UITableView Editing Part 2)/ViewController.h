//
//  ViewController.h
//  HomeWork Lesson 32 (UITableView Editing Part 2)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (strong, nonatomic) NSMutableArray *groupArray;
@property (strong, nonatomic) NSArray* teamsName; //название групп (секций)
@end

