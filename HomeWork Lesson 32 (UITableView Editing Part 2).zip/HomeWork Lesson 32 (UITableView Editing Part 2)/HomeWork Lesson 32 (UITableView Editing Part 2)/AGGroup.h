//
//  AGGroup.h
//  HomeWork Lesson 32 (UITableView Editing Part 2)
//
//  Created by Anton Gorlov on 01.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGGroup : NSObject
@property(strong,nonatomic) NSString* name;
@property(strong,nonatomic) NSArray* players;

@end
