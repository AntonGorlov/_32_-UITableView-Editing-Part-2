//
//  AGStudent.h
//  UITableView Editing Part 2 (Lesson 32)
//
//  Created by Anton Gorlov on 30.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGStudent : NSObject

@property (strong, nonatomic) NSString* firstName;
@property (strong, nonatomic) NSString* lastName;
@property (assign, nonatomic) float averageScore;

+ (AGStudent*) randomStudent;

@end
