//
//  ViewController.m
//  UITableView Editing Part 2 (Lesson 32)
//
//  Created by Anton Gorlov on 30.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGGroup.h"
#import "AGStudent.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self statusBarInsets];// отступы
    self.tableView.backgroundColor = [UIColor lightGrayColor];
    
    self.tableView.editing = YES; // возможность перетаскивать строки (режим редактирования) (Урок 31 "уровень студент")
    
    self.groupArray = [NSMutableArray array];
    
    
    for (int i = 0; i < (arc4random() % 6 + 5.f); i++) { //соз количество групп (секций)
        
        AGGroup* group = [[AGGroup alloc]init];
        group.name = [NSString stringWithFormat:@"group %d",i];
        
        NSMutableArray* array = [NSMutableArray array];
        
        
        for (int j = 0; j < (arc4random() % 11 +5.f ); j++) { //кол-во студентов в группе (рядов)
            [array addObject:[AGStudent randomStudent]];
        }
        
        group.students = array;
        
        [self.groupArray addObject:group]; // добавим в массив группы
    }
    
    [self.tableView reloadData]; //чтобы перезагрузить дату нашей tableView делаем reloadData
    
    self.navigationItem.title = @"Students"; // наз navigationBar
    
    UIBarButtonItem* editButtom = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit //добавляем кнопку,которая редактирует таблицы
                                                                                        target:self
                                                                                        action:@selector(actionEdit:)]; // метод,который реализуем
    
    self.navigationItem.rightBarButtonItem = editButtom; // уст-м кнопку справа без анимации
    
    
    UIBarButtonItem* addButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                              target:self
                                                                              action:@selector(actionAddSection:)];
    
    self.navigationItem.leftBarButtonItem = addButton; // уст-м кнопку слева без анимации
}


#pragma mark- Action 

//функционал кнопок


- (void) actionEdit:(UIBarButtonItem*) sender { // когда нажимаем на кнопку,то она переходит в "Edit" и вместо "Edit" появляется "Done"

    BOOL isEditing = self.tableView.editing; //узнаем редактируемся мы или нет
    
    [self.tableView setEditing:!isEditing animated:YES]; // ставим нашей tableView свойсто с анимацией (ставим обратное действие,если редактируем ставим - не редактируем и наоборот)
    
    UIBarButtonSystemItem item = UIBarButtonSystemItemEdit; // ставим новый  "item"
    
    if (self.tableView.editing) { //если tableView редактируется,то ...
        
        item = UIBarButtonSystemItemDone; // меняем на кнопку "Done"
    }
    
    //соз новую кнопку с нашим "item"
    
    UIBarButtonItem* editButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:item
                                                                               target:self
                                                                               action:@selector(actionEdit:)];
    
    [self.navigationItem setRightBarButtonItem:editButton animated:YES]; // устанавливаем кнопку справа с анимацией

}


- (void) actionAddSection:(UIBarButtonItem*) sender {//каждый раз,когда нажимаем на "+" будем добавлять какую-то группу к уже существующим
    
    AGGroup* group = [[AGGroup alloc]init];
    group.name = [NSString stringWithFormat:@"Group %ld",[self.groupArray count] + 1]; //берем кол-во групп (к примеру если "0" +1 к общему количеству)
    group.students = @[[AGStudent randomStudent],[AGStudent randomStudent]]; //рендомный студент (ставим по умолчанию) можем массив написать по другому
    /*
    или так
    group.students = [NSArray arrayWithObjects:[AGStudent randomStudent],[AGStudent randomStudent], nil];
*/
    
//создали группу,теперь нужно прицепить к массиву
    
    NSInteger newSectionIndex = 0; // новая секция под индексом "0"
    
    [self.groupArray insertObject:group atIndex:newSectionIndex]; //каждая новая группа соз по индексу "0"
    
    [self.tableView beginUpdates];// метод начинает обновление (внутри много методов!)
    
    NSIndexSet* insertSection = [NSIndexSet indexSetWithIndex:newSectionIndex];//обновим набор индексов
    
    UITableViewRowAnimation animation = UITableViewRowAnimationFade; //установим анимацию
    
    if ([self.groupArray count] > 1) { //если в массиве группы четное кол-во,то доб.слева,если не чет.- справа
        
        animation = [self.groupArray count] % 2 ? UITableViewRowAnimationLeft : UITableViewRowAnimationRight;     }
    //2-й вариант кода
    /*
    if ([self.groupArray count] > 1) {
        animation = [self.groupArray count] % 2;
        if ([self.groupArray count] % 2) {
            animation = UITableViewRowAnimationLeft;
        }else {
            animation = UITableViewRowAnimationRight;

        }
    }
    */
    [self.tableView insertSections:insertSection withRowAnimation:animation];
    [self.tableView endUpdates]; // метод заканчивает обновление
    
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents]; //запрещает все нажатия по всему App.(all Events)

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ // игнорирует все нажатия 0,5 сек
        if ([[UIApplication sharedApplication] isIgnoringInteractionEvents]) { // начинает игнорить
            [[UIApplication sharedApplication] endIgnoringInteractionEvents];//заканчивает игнорить
        }
    });
}
#pragma mark- UITableViewDataSource


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return [self.groupArray count]; //количество секций -это кол-во групп
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    return [[self.groupArray objectAtIndex:section] name];//выводим имя группы
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    AGGroup* group = [self.groupArray objectAtIndex:section];
    
    return [group.students count] + 1; //выводим количество студентов (количество рядов в секции будет на "1" больше чем раньше, так как добавляем кнопу "NewStudent")
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath { // нужно соз ячейку ,которая будет добавялть "NewStudent"
    
    if (indexPath.row == 0) { // если ряд по индексу "0" - показываем студента
        
        static NSString* addStudentIdentifier = @"AddStudentCell";
        
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:addStudentIdentifier];
        
        if (!cell) {
            
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:addStudentIdentifier];
            
            cell.textLabel.textColor = [UIColor blueColor];
            cell.textLabel.text = @"Add a new student";
        }
        return cell;
        
    }else { //или не по индексу "0"
    
        static NSString* identifier = @"cell";
        
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        }
        //заполняем нашу ячейку
        
        AGGroup* group = [self.groupArray objectAtIndex:indexPath.section];
        AGStudent* student = [group.students objectAtIndex:indexPath.row -1 ];//наш row -1 , так как 1-й элемент у нас "Add a new student",инекс начинаеться теперь с "1",поэтому вычитаем 1
        
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", student.firstName, student.lastName];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%1.0f", student.averageScore];
        
        
        if (student.averageScore == 5) {
            
            cell.detailTextLabel.textColor = [UIColor greenColor];
            
        }else if (student.averageScore == 4) {
            
            cell.detailTextLabel.textColor = [UIColor orangeColor];
            
        }else if (student.averageScore == 3) {
            
            cell.detailTextLabel.textColor = [UIColor cyanColor];
            
        }else {
            
            cell.detailTextLabel.textColor = [UIColor redColor];
        }
        
        return cell;
    }
    

}

//перетягивание ячеек  canMoveRowAtIndexPath и moveRowAtIndexPath

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {// метод,который вкл/выкл редактирование (перенос) ячеек по этому indexPath для такой section
    
    return indexPath.row > 0; // можем двигать,если row > 0, кнопка "AddStudent" = "0" (по индексу)
    
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    
    //sourceIndexPath - источник (откуда?)
    //destinationIndexPath - местоназначение (куда?-где?)
    
    
    AGGroup* sourceGroup = [self.groupArray objectAtIndex:sourceIndexPath.section]; // из какой группы переносим студентов
    AGStudent* student = [sourceGroup.students objectAtIndex:sourceIndexPath.row]; // какого студента (найдем нашего студента)
    
    NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sourceGroup.students]; // соз новый NSMutableArray на основе arrayстудентов
    
    if (sourceIndexPath.section == destinationIndexPath.section) {//если секция source такая же как и destination (если перенос в пределаъ группы)
        [tempArray exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row]; //метод,который внутри одной секции массива меняет по индексам
        sourceGroup.students = tempArray;
        
    }else {      //если не в пределах одной группы (section)
        
        [tempArray removeObject:student]; // удалим студента
        sourceGroup.students = tempArray;
        
        AGGroup* destinationGroup = [self.groupArray objectAtIndex:destinationIndexPath.section]; // переносим студента в новую группу
        tempArray = [NSMutableArray arrayWithArray:destinationGroup.students];
        [tempArray insertObject:student atIndex:destinationIndexPath.row];// добавляем студента по индексу
        destinationGroup.students = tempArray;

    }
}

//Делаем удаление студента

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
//метод,который говорит подтвердите Style выдиление. Программируем кнопку "Delete" (если программируем кнопку "Insert",то тоже вызовится этот метод)

    if (editingStyle == UITableViewCellEditingStyleDelete) { //если стиль "Delete", то программируем удаление,если "Insert",то программируем вставление
        
        AGGroup* sourceGroup = [self.groupArray objectAtIndex:indexPath.section]; // берем группу
        AGStudent* student = [sourceGroup.students objectAtIndex:indexPath.row - 1];

        //Взяли группу,нашли студента,теперь удаляем студента
        
        NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sourceGroup.students]; // берем NSMutableArray,соз массив Mutable на основе массива (не Mutuble)
        [tempArray removeObject:student]; //из этого массива удаляем студента
        sourceGroup.students = tempArray; //восстанавливаем обратно нашу группу
        
        [tableView beginUpdates];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft]; //вызываем метод,нам надо поставить indexPath,кот удаляем (удаляем налево)
        
        
        [tableView endUpdates];
        
        
    }
    
}


#pragma mark- UITableViewDelegate

//метод,который добавляет/убирает значки редактирования (красный кружок) и (зеленый кружок)

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return indexPath.row == 0 ? UITableViewCellEditingStyleNone : UITableViewCellEditingStyleDelete; // если indexPath.row == 0 - нельзя редактировать "AddStudent",для любого другого ряда можно возвращаем "Delete" ,чтобы можно было удалить
    
    //return UITableViewCellEditingStyleNone; //значки отсутствуют
}


- (nullable NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath NS_AVAILABLE_IOS(3_0) {

return @"Remove"; //Confirmation Button - кнопка подтверждения , изменяем название кнопки "Delete"
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {//метод,который при редактировании вкл/выкл  сдвиг ячейки (имя,фамилия) студента, Так как убрали значки редактирование (красный кружок) и (зеленый кружок) в методе "editingStyleForRowAtIndexPath"

    return NO;

}

- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath { //метод кот говорит :верини мне indexPath куда должна перейти ячейка при движении с indexPath на indexPath. С помощью этого метода не даем переставить ячейку (студента) выше кнопки "AddStudent" sourceIndexPath - начало, proposedDestinationIndexPath - предложенное местоназначение
    
    
    if (proposedDestinationIndexPath.row == 0) { // если row куда хотим перетянуть (студента) = "0" ,то...
        
        return sourceIndexPath; //возвращаем откуда хотели перейти
        
    }else { //если не равно "0"
    
        return proposedDestinationIndexPath;
    }

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { // когда нажимаем на "AddStudent" добавляем студента,когда нажали,чтото делаем (didSelect - сделали выбор).

    [tableView deselectRowAtIndexPath:indexPath animated:YES]; //если выбрали ряд,то сразу отменим выбор (если нажал,то срау отменим)
    
    if (indexPath.row == 0) { // если = 0, то добавляем студента
        AGGroup* group =[self.groupArray objectAtIndex:indexPath.section]; // берем группу по index секции (так как группы расположены по секциям)
        NSMutableArray* tempArray = nil; //students может быть nil
        
        if (group.students) { //если students существует
            tempArray = [NSMutableArray arrayWithArray:group.students]; //соз tempArray на основе массива студента (group.students)
        }else {
        
            tempArray = [NSMutableArray array]; //tempArray просто новый Array
        }
        
        
        
        NSInteger newStudentIndex = 0;
        
        [tempArray insertObject:[AGStudent randomStudent] atIndex:newStudentIndex]; // соз студента в index "0" (Добавим студента)
        group.students =tempArray; //изменяем группу так как данные берем из массива групп
        
        //теперь нужно обновлять нашу таблицу
        
        
        [self.tableView beginUpdates];
        
        NSIndexPath* newIndexPath = [NSIndexPath indexPathForItem:newStudentIndex +1 inSection:indexPath.section]; // соз indexPath для того элемента который вставили, ставим в "0" ,но бновить должны в "1",так как под "0" стоит "AddStudent"
        
        
        [self.tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationLeft];// у tableView нету уже "NSSet" (insert Section) у нас уже "NSArray", так как надо ставить "indexPath",а не"index"
        //или так расписать массив [self.tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationLeft];
        
        [self.tableView endUpdates];
        
        [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            if ([[UIApplication sharedApplication] isIgnoringInteractionEvents]) {
                [[UIApplication sharedApplication] endIgnoringInteractionEvents];
            }
        });
        
        
    }


}

#pragma mark- Methods

- (void) statusBarInsets {
    
    UIEdgeInsets topInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.contentInset = topInsets;
    self.tableView.scrollIndicatorInsets = topInsets;
    
    UIEdgeInsets rightInsets = UIEdgeInsetsMake(0, 0, 0, 20);
    self.tableView.separatorInset = rightInsets;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
